package com.miproyecto.appfinanciera.service;

import com.miproyecto.appfinanciera.model.Rol;
import com.miproyecto.appfinanciera.model.Usuario;
import com.miproyecto.appfinanciera.repository.RolRepository;
import com.miproyecto.appfinanciera.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

@Service
public class CustomOidcUserService extends OidcUserService {

    @Autowired
    private UsuarioRepository usuarioRepo;

    @Autowired
    private RolRepository rolRepo;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public OidcUser loadUser(OidcUserRequest userRequest) {
        System.out.println("🚀 Entrando a CustomOidcUserService.loadUser");

        OidcUser oidcUser = super.loadUser(userRequest);

        String email = oidcUser.getEmail();
        String nombre = oidcUser.getFullName(); // nombre completo desde Google

        Optional<Usuario> existente = usuarioRepo.findByEmail(email);
        Usuario usuario;

        if (existente.isEmpty()) {
            System.out.println("🌱 Usuario de Google nuevo. Registrando...");

            Usuario nuevo = new Usuario();
            nuevo.setEmail(email);
            nuevo.setNombre(nombre);
            nuevo.setContraseña(passwordEncoder.encode("oauth_google"));
            nuevo.setHabilitado(true);
            nuevo.setProveedor("GOOGLE");

            Rol rolUser = rolRepo.findByNombre("ROLE_USER");
            if (rolUser == null) {
                rolUser = new Rol();
                rolUser.setNombre("ROLE_USER");
                rolUser = rolRepo.save(rolUser);
                System.out.println("🔧 Rol creado en DB: " + rolUser.getNombre());
            }

            nuevo.setRoles(Collections.singleton(rolUser));

            try {
                usuario = usuarioRepo.save(nuevo);
                System.out.println("✅ Usuario guardado: " + usuario.getId());
            } catch (Exception e) {
                System.err.println("❌ Error al guardar usuario de Google:");
                e.printStackTrace();
                throw new RuntimeException("Error al guardar el usuario.");
            }
        } else {
            usuario = existente.get();
            System.out.println("🔁 Usuario de Google ya existe: " + email);
        }

        System.out.println("✅ Finalizado CustomOidcUserService para: " + email);
        return oidcUser;
    }
}
